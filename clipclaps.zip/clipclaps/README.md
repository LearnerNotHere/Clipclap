![CLIP CLAPS SCRIPT](imtubasya.jpg)
CLIP CLAPS SCRIPT FOR APPS ( ClipClaps )
<h3>BY : I'am Tubasya</h3>
<br>Is a script for Auto Claim Treasure Chest!!
<h2>How to use</h2>
<h3>Linux / Termux App:</h3>
<br>Enter the below command in the terminal :
<br>Install php :
<br><code>git clone https://github.com/Imtubasya/clipclaps</code>
<br><code>cd clipclaps</code>
<br>Edit Data :
<br><code>nano data.php</code>
<br><code>=> Input code ordered by me <=</code>
<br><code>if already press(CTRL+C+Enter)</code>
<br>Run :
<br><code>php bot.php</code>
<br>Enter!

<h3>Windows :</h3>
<br>Enter the below command in the CMD :
<br><code>php.exe bot.php</code>
<br>Enter!!
<br><br>
<h3>MY CHANNEL :</h3>
<br>Youtube : https://youtube.com/channel/UCBY7rVpHH49Na1MWfC0xKFA
<h3>END</h3>
